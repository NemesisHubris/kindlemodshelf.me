# Terminal Tetris

Tetris running in terminal (KTerm), intended for Kindles - but not only.

## Building

This program needs the ncurses library.

In order to search the current folder, build it with the command:

    gcc tetris.c -o tetris -Wl,-rpath '-Wl,$ORIGIN' -lncursesw

Otherwise build it simply by linking it to ncurses:

    gcc tetris.c -o tetris -lncursesw
