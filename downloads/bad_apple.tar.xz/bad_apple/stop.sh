#!/bin/sh

ps aux | grep "sh ./play.sh" | grep -v grep | awk '{ print $2 }' | xargs kill

pkill -9 gst-launch
pkill -9 sox

killall gmplay

rm /tmp/bad_apple_playing

# if [ -e /var/tmp/PLAYING ]
#     then
#         killall run_playlist.sh
#         killall play_single_file.sh
#         rm /var/tmp/PLAYING 
#     fi
# if [ -e /var/tmp/RADIO ]
#     then
#         killall play_internet_radio.sh
#         rm /var/tmp/RADIO
#     fi
# rm /var/tmp/PAUSED    
# pkill -9 gst-launch 
# pkill -9 sox 
# python3.9 /mnt/us/extensions/sox/create_menu.py