#!/bin/sh

if [ -e /tmp/bad_apple_playing ]
    then
        ./stop.sh
    else
        (./play.sh ./bad_apple.mp3) &
        (zcat -f /mnt/us/extensions/bad_apple/bad_apple.gmv.gz | /mnt/us/extensions/videos/gmplay) &
fi
