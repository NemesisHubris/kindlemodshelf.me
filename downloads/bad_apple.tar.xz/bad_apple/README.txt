TITLE: Sox Media Player v2

CONTAINS: KUAL extension to play media on PW4

NOTES:

Initial release: https://www.mobileread.com/forums/showthread.php?t=329588

This version includes new menu and functions:
[*]Play all files in /music
[*]Play any folder in /music
[*]Instant (as it is possible) play/pause
[*]Shuffle
[*]Volume control
[*]Forward (next track)

SETUP:

Put sox folder in /extensions
Put music in /music, folders included
If you need internet radio, put radio.txt in /music in this format: title;url

Thanks to Dave dhdurgee, geek1011, NiLuJe, trcm and yparitcher for their contributions.