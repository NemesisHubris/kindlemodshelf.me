
export XDG_DATA_DIRS=$(pwd)
./morris
