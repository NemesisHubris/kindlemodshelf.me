#!/bin/sh
# script to kill the sox stream playing

killall sox

rm /var/tmp/bookmark
rm /var/tmp/progress

